var compteur=1;
function next(){
	compteur++;
	if (compteur<6){
		document.getElementById('img_princ').src="intro/img_intro_"+compteur+".jpg"; // on change l'image
	}
	else{
		if(compteur==6){
			for (var i = 1; i < 7; i++) {
				MaJ_cookie("Q"+i+"_reussie",false); //création des cookies pour savoir si le joueur a fini les quêtes
			}
			document.location.href="Corps/page_principale.html"; // on va sur la page d'accueil
		}
	}

}