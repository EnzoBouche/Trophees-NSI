function start() {
  //definition canvas
  var fenetre = document.getElementById("fenetre");
  var ctx = fenetre.getContext("2d");
  //definition image
  //image lors deplcacement vers la droit
  var heroD = new Image();
  heroD.src = 'Hero.png';
  var pouletD = new Image(); 
  pouletD.src = 'Poulet.png';
  //image lors du deplacment vers la gauche
  var heroG = new Image();
  heroG.src = "Hero_.png"
  var pouletG = new Image();
  pouletG.src = "Poulet_.png"

  //proprietees
  var taille = 50;
  var x = 250;
  var y = 250;
  //image, initiallement mise à droite
  var hero = heroD
  var poulet = pouletD
  
  //position monstre
  var espace = taille + taille/10
  var diffx = 0;
  var diffy = espace ;
  //deplacements
    //changer la vitesse
    var v = 2;
  var dx = 0;
  var dy = -v;
  //controles
  var leftPressed = false;
  var rightPressed = false;
  var downPressed = false;
  var upPressed = false;
  //positions
    var a = nb_alea(fenetre.width - 25);
    var b = nb_alea(fenetre.height - 25);
    var compteur = 0;

  function deplacement() {
    //deplacement perso + monstre  
    //- d vers le haut et bas
    if (dy < 0) {
      if (leftPressed) {
        hero = heroG;
        poulet = pouletG;
        if (fenetre.width - taille <= x+ taille) {
          x += -taille
        }
        diffx = espace;
        diffy = 0;
        dx = -v;
        dy = 0;
      }
      
      if(rightPressed) {
        hero = heroD;
        poulet = pouletD;
        //si on est coller à la bordure se deplacer d'un coup de 50 pour pas que le monstre sois en dehors de la fenetre
        if (x <= taille) {
          x += taille
        }
        diffx = -espace;
        diffy = 0;
        dx = v;
        dy = 0;
      }
    }
    if (dy > 0) {
      if (leftPressed) {
        hero = heroG;
        poulet = pouletG;
        if (fenetre.width - taille <= x+ taille) {
          x += -taille
        }
        diffx = espace;
        diffy = 0;
        dx = -v;
        dy = 0;
      }
      if(rightPressed) {
        hero = heroD;
        poulet = pouletD;
        if (x <= taille) {
          x += taille
        }
        diffx = -espace;
        diffy = 0;
        dx = v;
        dy = 0
      }
    }
    //- d coté
    if (dx < 0) {
      if (downPressed) {
        if (y <= taille) {
          y += taille;
        }
        diffx = 0; 
        diffy = -espace;
        dx = 0;
        dy = v;
      }
      if (upPressed) {
        if (fenetre.height - taille <= y + taille) {
          y += -taille
        }
        diffx = 0;
        diffy = espace;
        dx = 0;
        dy = -v;
      }
    }
    if (dx > 0) {
      if (downPressed) {
        if (y <= taille) {
          y += taille;
        }
        diffx = 0;
        diffy = -espace;
        dx = 0;
        dy = v;
      }
      if (upPressed) {
        if (fenetre.height - taille <= y + taille) {
          y += -taille
        }
        diffx = 0;
        diffy = espace;
        dx = 0;
        dy = -v;
      }
    }
  }
  //positions oeufs
  //25 -> taille oeuf
  function nb_alea(max){
  // !! max non inclu
  // src: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Math/random
  // modifié ici pour afiché l'entiereter de l'image des oeufs 25 etant la taille des oeufs
    return Math.floor(Math.random()*(max/ 25))* 25;
  }

  function victoire() {
    //les points
    if (x<=a +12.5 && a + 12.5<= x + taille && y<= b+12.5 && b +12.5 <= y + taille) {
      a = nb_alea(fenetre.width - 25);
      b = nb_alea(fenetre.height - 25);
      v = v*1.1;
      compteur += 1;
      document.getElementById("compteur").innerHTML = compteur + "/10";
      if (compteur == 10) {
        alert("Victoire, vous avez tous les oeufs.");
        document.location.reload();
        clearInterval(interval); // Needed for Chrome to end game
        MaJ_cookie('Q6_reussie',true);
			  document.location.href="../page_principale.html";
      }
    }    
  }

  function jeu() {
    ctx.clearRect(0, 0, fenetre.width, fenetre.height);
    ctx.drawImage(document.getElementById("oeuf"), a, b, 25, 25);
    ctx.drawImage(hero, x, y, taille, taille);
    ctx.drawImage(poulet, x + diffx, y +diffy, taille, taille);
    deplacement();
    victoire();
    //avancer automatique
    x += dx;
    y += dy;
    //condition de defaite
    if (x + taille - 10 > fenetre.width || x  < -10 || y + taille - 8 > fenetre.height || y < -10) {
      alert("Défaite, vous vous êtes pris la barrière et la poule vous as eu.");
      document.location.reload();
      clearInterval(interval); // Needed for Chrome to end game
    }
  }
  
  var interval = setInterval(jeu, 10);
  //ecouteurs d'evenements
  document.addEventListener("keydown", keyDownHandler, false);
  document.addEventListener("keyup", keyUpHandler, false);
  function keyUpHandler(e) {
    if(e.key == "Right" || e.key == "ArrowRight") {
      rightPressed = false;
    }
    else if(e.key == "Left" || e.key == "ArrowLeft") {
      leftPressed = false;
    }
    else if(e.key == "Down" || e.key == "ArrowDown") {
      downPressed = false;
    }
    else if(e.key == "Up" || e.key == "ArrowUp") {
      upPressed = false;
    }
  }

  function keyDownHandler(e) {
    if(e.key == "Right" || e.key == "ArrowRight") {
      rightPressed = true;
    }
    else if(e.key == "Left" || e.key == "ArrowLeft") {
      leftPressed = true;
    }
    else if(e.key == "Down" || e.key == "ArrowDown") {
      downPressed = true;
    }
    else if(e.key == "Up" || e.key == "ArrowUp") {
      upPressed = true;
    }
  }
}