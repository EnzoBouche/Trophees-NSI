var vie_J=150;
var vie_O=150;
var level_J=1;
var level_O=1;
var matrice_gains=[	[0,1,2,-2,-1], 
					[-1,0,1,2,-2], 
					[-2,-1,0,1,2],
					[2,-2,-1,0,1],
					[1,2,-2,-1,0]];
var noms_choix=["Feuille", "Spock", 'Pierre', 'Ciseaux', 'Lézard']; 
var result=0;
var liste_timer=[];
/* correspondances : combat- 0
					 upgrade- 1
					 soin- 2
					 ABCDE-01234
					 combat_bonus- 0
					 soin_bonus- 1
*/

function nb_alea(max){
	// !! max non inclu
	// src: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Math/random
	return Math.floor(Math.random()*max);
}
function afficher_info(){
	document.getElementById("aff_vie_J").innerHTML=vie_J;
	document.getElementById("aff_vie_O").innerHTML=vie_O;
	document.getElementById("aff_level_J").innerHTML=level_J;
	document.getElementById("aff_level_O").innerHTML=level_O;
	return 0;	
}
function choix_selec(choix_J){
	// cette fonction va tirer au sort le choix de l'ordi et décider qui gagne :
	let choix_O=nb_alea(5);
	result=matrice_gains[choix_J][choix_O];
	let descrip=document.getElementById('description');
	document.getElementById('resul-tirage').innerHTML="Vous : "+noms_choix[choix_J]+ " ; Moi : "+noms_choix[choix_O]+ " ; Votre gain : "+result;
	if (result==0){
		descrip.innerHTML="MATCH NUL, recommencez";
		document.getElementById('nom_O').style.color="#FFFFFF";
		document.getElementById('nom_J').style.color="#FFFFFF";
	}
	else{
		if(result>0){
			descrip.innerHTML="C'est à vous de jouer";
			document.getElementById('nom_J').style.color="#FF0000";
			document.getElementById('nom_O').style.color="#FFFFFF";
			desactiver_but_tirage();
			activer_but_act();
			// Le joueur peut maintenant jouer
		}
		else{
			descrip.innerHTML="Votre adversaire a gagné le droit de jouer";
			document.getElementById('nom_O').style.color="#FF0000";
			document.getElementById('nom_J').style.color="#FFFFFF";
			desactiver_but_tirage();
			ordie_joue();
		}
	}
}

// FONCTIONS POUR ACTIVER OU NON LES BOUTONS D'ACTIONS
function desactiver_but_tirage(){
	let letr="ABCDE";
	for (let i = 0; i < letr.length; i++) {
		document.getElementById("choix_"+letr[i]).disabled=true;
	}
	document.getElementById('partie1').style.display="none";
}
function activer_but_tirage(){
	let letr="ABCDE";
	for (let i = 0; i < letr.length; i++) {
		document.getElementById("choix_"+letr[i]).disabled=false;
	}
	document.getElementById('partie1').style.display="inline";
}

function desactiver_but_act(){
	let acts=["combat", "amelior", "soin"];
	for (let i = 0; i < acts.length; i++) {
		document.getElementById("act_"+acts[i]).disabled=true;
	}
	document.getElementById('partie2').style.display="none";
}
function activer_but_act(){
	let acts=["combat", "amelior", "soin"];
	for (let i = 0; i < acts.length; i++) {
		document.getElementById("act_"+acts[i]).disabled=false;
	}
	document.getElementById('partie2').style.display="inline";
}

function activer_but_bonus(){
	document.getElementById("bonus_combat").disabled=false;
	document.getElementById("bonus_soin").disabled=false;
	document.getElementById('partie3').style.display="inline";
}
function desactiver_but_bonus(){
	document.getElementById("bonus_combat").disabled=true;
	document.getElementById("bonus_soin").disabled=true;
	document.getElementById('partie3').style.display="none";
}

// FONCTIONS D'ACTIONS
function action(numero, acteur){
	let descrip=document.getElementById('description');
	if (numero==0){
		if(acteur=="J"){
			vie_O-=10*level_J;
			descrip.innerHTML="Vous attaquez pour "+(10*level_J)+" dégats.";
		}
		else{
			vie_J-=10*level_O;
			descrip.innerHTML+="<br>Vous subissez "+(10*level_O)+" dégats.";
		}
	}
	else{
		if(numero==1){
			if(acteur=="J"){
				level_J++;
				descrip.innerHTML="Vous gagnez un niveau";
			}
			else{
				level_O++;
				descrip.innerHTML+="<br>Votre adversaire gagne un niveau";
			}
		}
		else{
			if (acteur=="J"){
				vie_J+=10*level_J;
				descrip.innerHTML="Vous récupérez "+(10*level_J)+" points de vie.";
			}
			if  (acteur=="O"){
				vie_O+=10*level_O;
				descrip.innerHTML+="<br>Votre adversaire récupère "+(10*level_O)+" points de vie.";
			}
		}
	}

	test_vie_max();
	afficher_info();
	test_vict();
	if (acteur=="J"){ //si le joueur jouait
		if(result>1){
			desactiver_but_act();
			activer_but_bonus();
			//document.getElementById("message3").innerHTML="Choississez votre bonus : "
		}
		else{
			activer_but_tirage();
			desactiver_but_act();
		}
	}
}

function action_bonus(numero,acteur){
	let descrip=document.getElementById('description');
	if (numero==0){
		if(acteur=="J"){
			vie_O-=5*level_J;
			descrip.innerHTML+="<br>Et vous attaquez pour "+(5*level_J)+" dégats.";
		}
		else{
			vie_J-=5*level_O;
			descrip.innerHTML+="<br>Et vous subissez "+(5*level_O)+" dégats.";
		}
	}
	else{
		if (acteur=="J"){
			vie_J+=5*level_J;
			descrip.innerHTML+="<br>Et vous récupérez "+(5*level_J)+" points de vie.";
		}
		if  (acteur=="O"){
			vie_O+=5*level_O;
			descrip.innerHTML+="<br>Et votre adversaire récupère "+(5*level_O)+" points de vie.";
		}
	}
	test_vie_max();
	afficher_info();
	test_vict();
	if (acteur=='J'){
		desactiver_but_bonus();
		activer_but_tirage();
	}
}

// FONCTION DE TEST :
function test_vie_max(){
	if (vie_J>135+15*level_J){
		vie_J=135+15*level_J;
	}
	if(vie_O>135+15*level_O){
		vie_O=135+15*level_O;
	}
}

function test_vict(){
	// !! le joueur doit survivre au combat
	if (vie_J<=0){
		alert("VOUS ÊTES MORT, Il faut recommencer !")
		reset();
	}
	else{
		if (vie_O<=0){
			alert("VOUS AVEZ GAGNE BRAVO !!!!!!!")
			final();
		}
	}
}

function ratio(vie,lv, vie_autr, lv_autr){
	//return (vie/(10*lv_autr))/(vie_autr/(10*lv));
	let vie_cop=vie;
	if (vie_cop>135+15*lv){
		vie_cop=135+15*lv;
	}
	return (vie_cop*lv)/(vie_autr*lv_autr);
}
// FONCTION 'INTELLIGENTE'
function choix_act(){
	if (10*level_O>=vie_J || (result<-1 && 15*level_O>=vie_J)){
		return [0,0]; // si on peut gagner, on joue cela
	}
	if (result==-1){
		// on calcule les ratio pour chaque action :
		let effets_possibles=[ratio(vie_O, level_O, vie_J-10*level_O, level_J), // si on attaque
							ratio(vie_O, level_O+1, vie_J, level_J),			// si on upgrade
							ratio(vie_O+10*level_O, level_O,vie_J, level_J)];	// si on soigne
		let maxi=effets_possibles[0];
		let indice=0;
		for (var i = 1; i < 3; i++) {
			if(effets_possibles[i]>maxi){
				indice=i;
				maxi=effets_possibles[i];
			}
		}
		return[indice,0];
	}
	else{ // ça va être moche
		let effets_possibles=[	[ratio(vie_O, level_O, vie_J-15*level_O, level_J), // si on attaque *2
								ratio(vie_O+5*level_O, level_O, vie_J-10*level_O, level_J)], // si on attaque puis soigne
								[ratio(vie_O, level_O+1, vie_J-5*(level_O+1), level_J), // si on upgrade puis attaque
								ratio(vie_O+5*(level_O+1), level_O+1, vie_J, level_J)], // si on upgarde puis soigne
								[ratio(vie_O+10*level_O, level_O,vie_J-5*level_O, level_J), // si on soigne puis attaque
								ratio(vie_O+15*level_O, level_O,vie_J, level_J)] // si on soigne *2
							];
		let maxi=effets_possibles[0][0];
		let indices=[0,0]
		for (var i = 0; i < 3; i++) {
			for (var j=0; j < 2; j++){
				if (effets_possibles[i][j]>maxi){
					indices=[i,j];
					maxi=effets_possibles[i][j];
				}
			}
		}
		return indices;
	}
	return [0, 0]; // si jamais on n'est pas sorti de la fonction (erreur) on attaque bêtement
	// on sépare la fonction choix de la fonction exécuter pour
	// pouvoir l'arrêter immédiatement avec un return
}
function ordie_joue(){
	actions=choix_act();
	liste_timer.push(setTimeout(action,1000,actions[0],'O'));
	if (result<-1){
		liste_timer.push(setTimeout(action_bonus, 1000,actions[1],'O'));
	}
	liste_timer.push(setTimeout(activer_but_tirage, 1000));
}


function reset(){
	location.reload();
}

function init(){
	afficher_info();
	document.getElementById('intro').style.display='inline';
	desactiver_but_tirage();
	desactiver_but_act();
	desactiver_but_bonus();
}
function fin_intro(){
	document.getElementById('intro').style.display='none';
	activer_but_tirage();
}
function final(){
	document.getElementById('all').innerHTML="<p><img src='img_finale.png'></p>"
	document.body.style.backgroundImage="none";
}