var player = 'X';
var compteur = 0;
var liste_cases=['b11', 'b12', 'b13', 'b21', 'b22', 'b23', 'b31', 'b32', 'b33'];

function checkVictory(pl) { //on teste tous les cas de victoire possible
	return (pl == document.getElementById("b11").value && pl == document.getElementById("b12").value
	&& pl == document.getElementById("b13").value) ||
	(pl == document.getElementById("b21").value && pl == document.getElementById("b22").value &&
	pl == document.getElementById("b23").value) ||
	(pl == document.getElementById("b31").value && pl == document.getElementById("b32").value &&
	pl == document.getElementById("b33").value) ||
	(pl == document.getElementById("b11").value && pl == document.getElementById("b21").value &&
	pl == document.getElementById("b31").value) ||
	(pl == document.getElementById("b12").value && pl == document.getElementById("b22").value &&
	pl == document.getElementById("b32").value) ||
	(pl == document.getElementById("b13").value && pl == document.getElementById("b23").value &&
	pl == document.getElementById("b33").value) ||
	(pl == document.getElementById("b11").value && pl == document.getElementById("b22").value &&
	pl == document.getElementById("b33").value) ||
	(pl == document.getElementById("b13").value && pl == document.getElementById("b22").value &&
	pl == document.getElementById("b31").value);
}

function joueur_joue(position){
	case_click(position);
	if(!checkVictory("X") && compteur!=9)
	{
		document.getElementById('message').innerHTML="À moi !";
		setTimeout(ordi_joue,500);
	}
}

function case_click(position){
	document.getElementById(position).value=player;
	document.getElementById(position).disabled=true;
	compteur++;
	if (checkVictory(player)) 
	{
		if(player=='X'){ 
			document.getElementById("message").innerHTML = "Vous avez gagné !";
			alert("Bravo, vous avez terminé cette quête !");
			MaJ_cookie('Q1_reussie',true); // quête réussie
			document.location.href="../page_principale.html"; // on va sur la page d'accueil
		}
		else{
			document.getElementById("message").innerHTML = "J'ai gagné !";
		}
		
		for (let k = 1; k <= 3; k++) 
		{
			for (let l = 1; l <= 3; l++)
			{
				document.getElementById("b" + k + l).disabled = true;
			}
		}
	}
	else
	{
		if (compteur==9) // si ttes les cases occupées
		{
			document.getElementById("message").innerHTML = "Match nul !";
		}
		else
		{
			if (player == 'X') 
			{
				player = 'O';
			} 
			else 
			{
				player = 'X';
			}
		}
	}
}

function reset(){
	player="X";
	compteur=0;
	for (let i=1; i<=3; i++){
		for(let j=1;j<=3;j++){
			document.getElementById("b"+i+j).disabled=false;
			document.getElementById("b"+i+j).value="";
		}
	}
	document.getElementById('message').innerHTML="Jouez !"
}

function coups_gagnants(pl){
	// cette fonction nous renvoie la liste des coups gagnants du joueur pl
	let i=0;
	let test=false;
	let sortie=[];
	while (i<9 && !test) {
		if (!document.getElementById(liste_cases[i]).disabled)
		{
			document.getElementById(liste_cases[i]).value=pl;
			if (checkVictory(pl)){
				sortie.push(liste_cases[i]);
			}
			document.getElementById(liste_cases[i]).value='';
		}
		i++;
	}
	return sortie;
}

function ordi_joue(pl){ // Cette fonction s'adapte selon que ce soit le joueur 1 ou 2 qui soit l'ordinateur
	let a_joue=false; // cette variable permet 1 d'arrêter les boucles, 2 de savoir si on a joué
	let autre='X'
	if (pl=="X") {autre='O';}
	let liste=[]; // Cette variable stockera différentes liste de case au fur et a mesure

	// Primo, on teste si l'on peut gagner :
	liste=coups_gagnants(pl);
	if (liste.length!=0){
		case_click(liste[0]);
		a_joue=true;
	}

	if (!a_joue){ // si on n'a pas déjà joué, on va tenter d'empêcher l'autre de gagner
		liste=coups_gagnants(autre);
		if(liste.length!=0){
			case_click(liste[0]);
			a_joue=true;
		}
	}
	if (!a_joue){ // si on a toujours pas, on va jouer assez bêtement dans la 1ere case parmis :
				// centre, coins, cotés
		liste=['b22', 'b11', 'b13', 'b31', 'b33', 'b12', 'b21', 'b23', 'b32'];
		let i=0;
		while(i<9 && !a_joue){
			if(!document.getElementById(liste[i]).disabled){
				case_click(liste[i]);
				a_joue=true;
			}
			i++;
		}
	}
	// La boucle précédent a forcément abouti à un coup puisque ttes les cases ne sont pas désactivées (sinon nous sommes en match nul)
	if(!checkVictory('O'))
	{
			document.getElementById('message').innerHTML="Jouez !";
	}
	return 0;
}