function MaJ_cookie(name,valeur){
	document.cookie =name+"="+valeur+"; path=/ ; max-age=86400;domain=; SameSite=Lax";
	// les cookies sont stockés pendant un jour
}
function recup_cookie(name){
	let cookielist=document.cookie.split(";");
	for(let j=1; j<cookielist.length; j++){
		cookielist[j]=cookielist[j].slice(1); // on enlève l'espace devant ts les cookies sauf le premier
	}
	for(let i=0; i<cookielist.length; i++){
		if(cookielist[i].split("=")[0] == name){
		return cookielist[i].split("=")[1];
		}
	}
	return "ERREUR cookie non trouvé !";// si on n'est pas sorti de la fonction
}

/*Code à ajouter dans le HTML

<script type="text/javascript" src="../script_cookie.js"></script>

*/