var message_clair="ALICE, MA BIEN AIMEE, NE T'EN FAIS PAS. JE SUIS JUSTE ALLE ACHETER LES CHOUQUETTES !";
var alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var liste_0to25=[];
var clef_user=[];
var message_crypt="";
var tentative_message_clair="";

for(i=0; i<26;i++){
	liste_0to25.push(i); // liste des entiers entre 0 et 25
	clef_user.push("_"); // on crée une liste avec que des _
}

function est_lettre(char){
	let test=false;
	let i=0;
	while (test==false && i<alphabet.length){
		test=(alphabet[i]==char);
		i++;
	}
	return test;
}

function get_indice(char){
	// éviter d'utiliser cette fonction sans avoir fait le test
	// est_lettre
	let test=false;
	let i=0;
	while (test==false && i<alphabet.length){
		test=(alphabet[i]==char);
		i++;
	}
	if (test){
		return i-1;
	}
	else{ return 26;}
}
function nb_alea(max){
	// !! max non inclu
	// src: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Math/random
	return Math.floor(Math.random()*max);
}
function permutation(liste){
	new_liste=[]
	while(0<liste.length){
		indice=nb_alea(liste.length);
		new_liste.push(liste[indice]);
		liste.splice(indice,1);
	}
	return new_liste
}
function crypter(msg){
	let clef=permutation(liste_0to25); 
	sortie="";
	for (j=0;j<msg.length;j++){
		if(est_lettre(msg[j])) // on ne modifie pas les caractères qui ne sont pas des lettres
		{
			sortie+=alphabet[clef[get_indice(msg[j])]];
		} 
		else{ sortie+=msg[j];}
	}
	liste_0to25=[];
	for(i=0; i<26;i++){
	liste_0to25.push(i);
	}
	return sortie;
}

function tentative_decrypt(clef_sup,txt){
	let clair="";
	for(i=0; i<txt.length;i++){

		if(est_lettre(txt[i])){ // on ne modifie pas les caractères qui ne sont pas des lettres
			clair+=clef_sup[get_indice(txt[i])]
		}
		else{ clair+=txt[i];}
	}
	return clair
}
function MaJ_clef(){
	var letr1=document.getElementById("ltr_crypt").value[0].toUpperCase(); // on ne prend que les permières lettres
	var letr2=document.getElementById("ltr_clef").value[0].toUpperCase();
	clef_user[get_indice(letr1)]=letr2;
	afficher_clef();
	tentative_message_clair=tentative_decrypt(clef_user,message_crypt);
	for (var i = 0; i < tentative_message_clair.length; i++) {
		document.getElementById('ltr_msg_clair_'+i).value=tentative_message_clair[i];
	}
	
	if (tentative_message_clair==message_clair){
		for (var i = 0; i < message_clair.length; i++) {
			document.getElementById('ltr_msg_clair_'+i).style.backgroundColor="#00FF00";
			document.getElementById('ltr_msg_clair_'+i).disabled=true;
			document.getElementById('ltr_msg_clair_'+i).style.color="#000000";
			document.getElementById('ltr_msg_crypt_'+i).style.backgroundColor="#00FF00";
			document.getElementById('ltr_msg_crypt_'+i).disabled=true;
			document.getElementById('ltr_msg_crypt_'+i).style.color="#000000";
		}
		document.getElementById('valid_clef').disabled=true;
		document.getElementById('valid_clef').style.color="#000000";
		MaJ_cookie('Q5_reussie',true);
		alert("BRAVO ! Vous avez réussi ce niveau.");
		document.location.href="../page_principale.html"; // on va sur la page d'accueil
	}
}
function afficher_clef(){
	let sortie="";
	for(i=0;i<clef_user.length;i++){
		sortie+=clef_user[i];
	}
	document.getElementById('clef_affich').innerHTML=sortie;

}
function initialisation(){
	document.getElementById('corps').style.display='none';
	let HTML_msg_crypt='';
	message_crypt=crypter(message_clair);
	for (var i = 0; i < message_crypt.length; i++) {
		HTML_msg_crypt+='<input type="button" value="'+message_crypt[i]+'" id="ltr_msg_crypt_'+i+'" class="bout_ltr_crypt" onclick="select_ltr_crypt(\''+message_crypt[i]+'\')">';
	}
	document.getElementById('msg_crypt').innerHTML=HTML_msg_crypt;
	afficher_clef();
	tentative_message_clair=tentative_decrypt(clef_user,message_crypt);
	let HTML_msg_clair="";
	for (var i = 0; i < tentative_message_clair.length; i++) {
		HTML_msg_clair+='<input type="button" value="'+tentative_message_clair[i]+'" id="ltr_msg_clair_'+i+'" class="bout_ltr_clair" onclick="select_ltr_clair('+i+')">'
	}
	document.getElementById('msg_semi_clair').innerHTML=HTML_msg_clair;
	return 0;
}
function etape_2(){
	document.getElementById('corps').style.display='inline';
	document.getElementById('intro').style.display='none';
}
function select_ltr_crypt(ltr){
	if (est_lettre(ltr)){
		document.getElementById('ltr_crypt').value=ltr;
		for (var i = 0; i < message_crypt.length; i++) {
			if (document.getElementById('ltr_msg_crypt_'+i).value==ltr){
				document.getElementById('ltr_msg_crypt_'+i).style.backgroundColor="#FF9999";
				document.getElementById('ltr_msg_clair_'+i).style.backgroundColor="#9999FF";
			}
			else{
				document.getElementById('ltr_msg_crypt_'+i).style.backgroundColor="#FFCCCC";
				document.getElementById('ltr_msg_clair_'+i).style.backgroundColor="#CCCCFF";
			}
		}
	}
}
function select_ltr_clair(index){
	select_ltr_crypt(document.getElementById('ltr_msg_crypt_'+index).value);
}