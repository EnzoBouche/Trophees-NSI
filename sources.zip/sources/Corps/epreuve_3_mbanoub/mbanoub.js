function start() {
	var canvas = document.getElementById("myCanvas");
	var ctx = canvas.getContext("2d");
	var gateau = new Image();//on utilise cookie dans le script_cookies
	gateau.src = "cookie.png"
	var Taille = 100

	var paddleHeight = 10;
	var paddleWidth = 100;
	var paddleX = (canvas.width-paddleWidth)/2;
	var paddleY = canvas.height- 2 * paddleHeight


	var rightPressed = false;
	var leftPressed = false;

	var x = nb_alea(canvas.width - Taille);
	var y = 0;
	var v = 4;
	var x2 = nb_alea(canvas.width - Taille);
	var y2 = 0;

	var compteur = 0;

	function nb_alea(max){
    // !! max non inclu
    // src: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Math/random
    // modifié ici pour afiché l'entiereter de l'image, pour des cookies de taille 100x100 
    	return Math.floor(Math.random() * (max / 50)) * 50;
  	}

	function drawPaddle() {
   		ctx.beginPath();
  		ctx.rect(paddleX, paddleY, paddleWidth, paddleHeight);
	    ctx.fillStyle = "#ffffff";
	    ctx.fill();
	    ctx.closePath();
	}
	function jeu() {
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		ctx.drawImage(gateau, x, y, Taille, Taille)
	    drawPaddle();
	    defaite();
	    score();
	    deplacement();
	    y += v;
	    //ajout des cookies au fur et à mesure
	    if (2 <= compteur ) {
			ctx.drawImage(gateau, x2, y2, Taille, Taille);
		if (y2 == 0) {
			if (y2 + Taille *2 <= y) {
				y2 += 1
			}
		}
		else {
			y2 += v;
		}
		}
		}
	function defaite() {
		if (canvas.height <= y + Taille) {
			alert("Défaite, un cookie est tombé.");
      		document.location.reload;
      		clearInterval(interval);
		}
		if (canvas.height <= y2 + Taille) {
			alert("Défaite, un cookie est tombé.");
      		document.location.reload;
      		clearInterval(interval);
		}
	}
	function  score() {
		if (x + Taille/2 >= paddleX &&  x + Taille/2 <= paddleX + paddleWidth && y + Taille >= paddleY) {
      		x = nb_alea(canvas.width - Taille);
			y = 0;
			compteur += 1;
		}
		if (x2 + Taille/2 >= paddleX &&  x2 + Taille/2 <= paddleX + paddleWidth && y2 + Taille >= paddleY && compteur < 14) {
			x2 = nb_alea(canvas.width - Taille);
			while (x2 == x) {
				x2 = nb_alea(canvas.width - Taille);
			}
			y2 = 0;
			compteur += 1;
		}
		 //condition de victoire
	    if (15 <= compteur) {
	    	alert("Victoire, tu as sauvé tous les cookies !");
      		document.location.reload;
      		clearInterval(interval);
			MaJ_cookie('Q3_reussie',true);
			document.location.href="../page_principale.html";
	    }
	}
	function deplacement() {
	    if (rightPressed) {
			paddleX += 10;
 			if (paddleX + paddleWidth > canvas.width) {
 				paddleX = canvas.width - paddleWidth;
 			}
		}
		else if (leftPressed) {
 			paddleX -= 10;
 			if (paddleX < 0) {
 				paddleX = 0;
 			}
		}
	}
	var	 interval = setInterval(jeu, 10);
		document.addEventListener("keydown", keyDownHandler, false);
	function keyDownHandler(e) {
 		if(e.key == "Right" || e.key == "ArrowRight") {
 			rightPressed = true;
 		}
 		else if(e.key == "Left" || e.key == "ArrowLeft") {
 			leftPressed = true;
 		}
	}
	document.addEventListener("keyup", keyUpHandler, false);
	function keyUpHandler(e) {
 		if(e.key == "Right" || e.key == "ArrowRight") {
 			rightPressed = false;
 		}
 		else if(e.key == "Left" || e.key == "ArrowLeft") {
 			leftPressed = false;
 		}
	}
}x