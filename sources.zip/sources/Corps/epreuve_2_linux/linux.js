function start() {
	var canvas = document.getElementById("myCanvas");
	var ctx = canvas.getContext("2d");

	var pin = new Image();
	pin.src = "pin.png";

	var glace = new Image();
	glace.src = "glace.png"
	var glaceHeight = 100

	var paddleHeight = 10;
	var paddleWidth = 100;
	var paddleX = (canvas.width-paddleWidth)/2;
	var paddleY = canvas.height- 2 * paddleHeight


	var rightPressed = false;
	var leftPressed = false;

	var x = nb_alea(canvas.width - 50);
	var y = 0;
	var v = 5;
	var x2 = nb_alea(canvas.width - 50);
	var y2 = 0;
	var x3 = nb_alea(canvas.width - 50);
	var y3 = 0;
	var x4 = nb_alea(canvas.width - 50);
	var y4 = 0;

	var compteur = 0;

	function nb_alea(max){
    // !! max non inclu
    // src: https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Math/random
    // modifié ici pour aficher l'entièreter de l'image, pour des pinguins de taille 50x50 
    	return Math.floor(Math.random() * (max / 50)) * 50;
  	}

	function drawPaddle() {
   		ctx.beginPath();
  		ctx.rect(paddleX, paddleY, paddleWidth, paddleHeight);
	    ctx.fillStyle = "white";
	    ctx.fill();
	    ctx.closePath();
	}
	function jeu() {
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		ctx.drawImage(glace, x, y, 50, glaceHeight)
		ctx.drawImage(pin, paddleX + 25, paddleY - paddleHeight - 40, 50, 50)
	    drawPaddle();
	    tombe();
	    defaite();
	    deplacement();
	    y += v;
	    if (2 <= compteur) {
			ctx.drawImage(glace, x2, y2, 50, glaceHeight);
			y2 += v;
		}
		if (10 <= compteur) {
			ctx.drawImage(glace, x3, y3, 50, glaceHeight);
			y3 += v;
		}
		if (25 <= compteur) {
			ctx.drawImage(glace, x4, y4, 50, glaceHeight);
			y4 += v;
		}
	    //condition de victoire
	    if (50 <= compteur) {
	    	alert("Victoire, le pingouin est sauvé");
      		document.location.reload;
      		clearInterval(interval);
			MaJ_cookie('Q2_reussie',true);
			document.location.href="../page_principale.html";
	    }
	}
	function tombe() {
		if (canvas.height <= y + glaceHeight ) {
      		x = nb_alea(canvas.width - 50);
			y = 0;
			compteur += 1;
		}
		if (canvas.height <= y2 + glaceHeight) {
			x2 = nb_alea(canvas.width - 50);
			while (x2 == x) {
				x2 = nb_alea(canvas.width - 50);
			}
			y2 = 0;
			compteur += 1;
		}
		if (canvas.height <= y3 + glaceHeight) {
			x3 = nb_alea(canvas.width - 50);
			while (x3 == x || x3 == x2) {
				x3 = nb_alea(canvas.width - 50);
			}
			y3 = 0;
			compteur += 1;
		}
		if (canvas.height <= y4 + glaceHeight) {
			x4 = nb_alea(canvas.width - 50);
			while (x4 == x || x4 == x2 || x4 == x3) {
				x4 = nb_alea(canvas.width - 50);
			}
			y4 = 0;
			compteur += 1;
		}
	}
	function defaite() {
		if (x <= paddleX + 25 && paddleX + 25 <= x + 50 && paddleY - paddleHeight - 35 <= y + glaceHeight || x <= paddleX + 75 && paddleX + 75 <= x + 50 && paddleY - paddleHeight - 35 <= y + glaceHeight) {
			alert("Defaite, le pingouin est mort.");
      		document.location.reload;
      		clearInterval(interval);
		}
		if (x2 <= paddleX + 25 && paddleX + 25 <= x2 + 50 && paddleY - paddleHeight - 35 <= y2 + glaceHeight || x2 <= paddleX + 75 && paddleX + 75 <= x2 + 50 && paddleY - paddleHeight - 35 <= y2 + glaceHeight) {
			alert("Defaite, le pingouin est mort.");
      		document.location.reload;
      		clearInterval(interval);
		}
		if (x3 <= paddleX + 25 && paddleX + 25 <= x3 + 50 && paddleY - paddleHeight - 35 <= y3 + glaceHeight || x3 <= paddleX + 75 && paddleX + 75 <= x3 + 50 && paddleY - paddleHeight -35 <= y3 + glaceHeight) {
			alert("Defaite, le pingouin est mort.");
      		document.location.reload;
      		clearInterval(interval);
		}
		if (x4 <= paddleX + 25 && paddleX + 25 <= x4 + 50 && paddleY - paddleHeight - 35 <= y4 + glaceHeight || x4 <= paddleX + 75 && paddleX + 75 <= x4 + 50 && paddleY - paddleHeight - 35 <= y4 + glaceHeight) {
			alert("Defaite, le pingouin est mort.");
      		document.location.reload;
      		clearInterval(interval);
		}
	}
	function deplacement() {
	    if (rightPressed) {
			paddleX += 7;
 			if (paddleX + paddleWidth > canvas.width) {
 				paddleX = canvas.width - paddleWidth;
 			}
		}
		else if (leftPressed) {
 			paddleX -= 7;
 			if (paddleX < 0) {
 				paddleX = 0;
 			}
		}
	}
	var	 interval = setInterval(jeu, 10);
		document.addEventListener("keydown", keyDownHandler, false);
	function keyDownHandler(e) {
 		if(e.key == "Right" || e.key == "ArrowRight") {
 			rightPressed = true;
 		}
 		else if(e.key == "Left" || e.key == "ArrowLeft") {
 			leftPressed = true;
 		}
	}
	document.addEventListener("keyup", keyUpHandler, false);
	function keyUpHandler(e) {
 		if(e.key == "Right" || e.key == "ArrowRight") {
 			rightPressed = false;
 		}
 		else if(e.key == "Left" || e.key == "ArrowLeft") {
 			leftPressed = false;
 		}
	}
}